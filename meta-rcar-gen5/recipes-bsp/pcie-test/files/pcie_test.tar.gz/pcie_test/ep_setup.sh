#!/bin/sh
# SPDX-License-Identifier: GPL-2.0
echo "Endpoint setup"

mount -t configfs none /sys/kernel/config
cd /sys/kernel/config/pci_ep
mkdir functions/pci_epf_test/func1
cd /sys/kernel/config/pci_ep
echo 0x16c3 > functions/pci_epf_test/func1/vendorid
echo 0xedda > functions/pci_epf_test/func1/deviceid
echo 32 > functions/pci_epf_test/func1/msi_interrupts
cd /sys/kernel/config/pci_ep
ln -s functions/pci_epf_test/func1/ controllers/db000000.pcie6-ep/
cd /sys/kernel/config/pci_ep
echo 1 > controllers/db000000.pcie6-ep/start
echo "completed."

