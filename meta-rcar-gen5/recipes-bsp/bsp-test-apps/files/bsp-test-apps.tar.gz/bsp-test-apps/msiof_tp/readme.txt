====================================================================
2.1. Normal System Test

test_msiof_normal_trtx.sh arg1 arg2 arg3
args: 
  arg1  m:master mode or s:slave mode
  arg2  test no
  arg3  p:pio or d:dma[Optional]


master mode, 
test no:
 1: Communication test. Master transmission.
 2: Communication test. Master reception.
 3: Communication test. Master Send and receive.

test no:
 1: Communication test. Slave reception.
 2: Communication test. Slave transmission.
 3: Communication test. Slave Send and receive.


#master mode, test number, dma
./test_msiof_normal_trtx.sh m 1
./test_msiof_normal_trtx.sh m 2
./test_msiof_normal_trtx.sh m 3

#slave mode, test number, pio
./test_msiof_normal_trtx.sh s 1 p
./test_msiof_normal_trtx.sh s 2 p
./test_msiof_normal_trtx.sh s 3 p

#master mode, test number, pio
./test_msiof_normal_trtx.sh m 1 p
./test_msiof_normal_trtx.sh m 2 p
./test_msiof_normal_trtx.sh m 3 p



====================================================================
2.2. Abnormal System Test
====================================================================

args master or slave, pio or dma 
./test_msiof_abnormal_transfer_test.sh m d
./test_msiof_abnormal_transfer_test.sh s d

#pio
./test_msiof_abnormal_transfer_test.sh m p
./test_msiof_abnormal_transfer_test.sh s p

./test_msiof_abnormal_word_size.sh m
./test_msiof_abnormal_word_size.sh s


Example:
./22_test_msiof_abnormal_transfer_test.sh 1 3 s d
1: Master channel
3: Slave channel
s: Slave test
d: DMA mode

./22_test_msiof_abnormal_transfer_test.sh 3 m p
3: Master channel
m: Master test
p: PIO mode

./22_test_msiof_abnormal_transfer_test.sh m p
m: Master test
  noet: The default channel is used.(Master:MSIOF3)
p: PIO mode

./22_test_msiof_abnormal_transfer_test.sh s p
s: Slave test
  noet: The default channel is used.(Master:MSIOF1, Slave:MSIOF3)
p: PIO mode


====================================================================
2.3. Boundary Value Test
====================================================================

./test_msiof_boundary_transfer_test.sh m d
./test_msiof_boundary_transfer_test.sh m p

./test_msiof_boundary_transfer_test.sh s d
./test_msiof_boundary_transfer_test.sh s p



./test_msiof_boundary_word_size.sh m
./test_msiof_boundary_word_size.sh s


===============================================================================
2.4. Modularization Test
===============================================================================
No.1
   # ./test_msiof_normal_trtx.sh m 1

No.2

No.3
   # ./test_msiof_normal_trtx.sh m 1

   # ./test_msiof_normal_trtx.sh m 3


===============================================================================
2.5. gcov Test
===============================================================================
   # ./test_msiof_normal_trtx.sh s 3

   # ./test_msiof_normal_trtx.sh m 3

example:
./test_msiof_transfer -m -n 1 -rw rw -b 8 -w 270 -f 1000000


===============================================================================
2.6.Suspend to RAM test
===============================================================================
No.1 [B2]
./test_msiof_normal_trtx.sh m 3
./test_msiof_normal_trtx.sh m 3 p

./test_msiof_normal_trtx.sh s 3
./test_msiof_normal_trtx.sh s 3 p

�g�ݍ��킹
 master: dma,  pio
 slave : dma,  pio



No.2 [B3]
master test:
./test_msiof_normal_trtx.sh m 3 &
./test_msiof_normal_trtx.sh m 3 p &

slave test:
./test_msiof_normal_trtx.sh s 3 &
./test_msiof_normal_trtx.sh s 3 p &


===============================================================================
3.1. Performance Test
===============================================================================

No.1
./31_performance_1.sh 1000000
./31_performance_1.sh 4000000
./31_performance_1.sh 8000000

No.02
# cd msiof_tp/sh
# ./test_msiof_normal_trtx.sh m 3 &
# top -b -d 1 -n 10 > aaa.txt
# grep sh aaa.txt

No.03 16.66MHz

./31_performance_1.sh 16666666


No.6 QoS
./31_performance_1.sh 16666666






====================================================================
3.3. Load Durability Test
====================================================================

[command format]
./test_msiof_endurance.sh <time> <DMA or PIO> [SoC type]
time: 1800
dma or pio: d:DMA, p:PIO
[SoC type]: R-Car H3/M3/M3N: No need
            R-Car E3: e3 

If "e3" is specified, transfer is performed with MSIOF0.

// DMA test
[R-Car H3/M3/M3N]
./test_msiof_endurance.sh 1800 d
[R-Car E3]
./test_msiof_endurance.sh 1800 d e3

// PIO test
[R-Car H3/M3/M3N]
./test_msiof_endurance.sh 1800 p
[R-Car E3]
./test_msiof_endurance.sh 1800 p e3

