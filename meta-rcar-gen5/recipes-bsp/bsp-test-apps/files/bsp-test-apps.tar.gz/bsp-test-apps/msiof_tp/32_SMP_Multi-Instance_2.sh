#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################
TEST_TIME=0
END_TIME=10		# 10sec
TERGET=0		# h:H3, m:m3

###############################################################################
#
# Main
#
###############################################################################
sync

echo
echo "***** SMP Multi-Instance Test No.02 start  *****"
#echo

taskset -c 0 ./32_SMP_Multi-Instance_transfar.sh s &
sleep 1s

# master mode
taskset -c 1 ./32_SMP_Multi-Instance_transfar.sh m

sleep 3s
echo "**** No.02 end ****"


