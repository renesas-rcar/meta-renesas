#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################
start_time=`date +%s`
test_time=0

MSIOF_TP="test_msiof_transfer"
PREFNAME="ch"
SUFFNAME_TX="_tx_data.dat"
SUFFNAME_RX="_rx_data.dat"
MASTER_TX="ch0_tx_data.dat"
MASTER_RX="ch0_rx_data.dat"
SLAVE_TX="ch1_tx_data.dat"
SLAVE_RX="ch1_rx_data.dat"

#TRANSFER_MODE=(1)
# 8bit, 16bit, 32bit
WORD_SIZE=(8 16 32)
WORDS_DMA1=(16 256 260 272 378 512)
WORDS_DMA2=(16 110 256 264 272 380 512)
WORDS_DMA3=(4 16 116 256 268 272 384 512)
# 8bit, 16bit, 32bit
WORDS_PIO1=(9 277 508)
WORDS_PIO2=(8 270 380)
WORDS_PIO3=(12 260 288)

ERR_WORD_SIZE=(7 9 15 17 31 33)

# Board type
# 0:Salvator-x/xs(H3, M3, M3N), 1:Ebisu(E3)
BOARD_TYPE=0

# test MSIOF channels
#  MSIOF0, MSIOF1, MSIOF2, MSIOF3 -> ch0-3
#   MSIOF1=spidev2.0, MSIOF3=spidev4.0
MASTER_CH=0
SLAVE_CH=1

# 0:Master mode
# 1:Slave mode
TRANSMODE=0
# 1:Master Tx, Slave Rx
# 2:Master Rx, Slave Tx
# 3:Master TxRx, Slave TxRx
TESTMODE=3
MASTERRW="rw"
SLAVERW="rw"
SPEED=4000000
# Fixd data 0xAA = 170
# set to Decimal number
FIXDATA=170

###############################################################################
#
# Methods
#
###############################################################################

transfer()
{
WORD_SIZE=$1
LEN=$2
	if [ $TRANSMODE -eq 1 ] ; then
		unset MASTER_CH
		unset SLAVE_CH
		MASTER_CH=0
		SLAVE_CH=1
		MASTER_TX=$PREFNAME$MASTER_CH$SUFFNAME_TX
		MASTER_RX=$PREFNAME$MASTER_CH$SUFFNAME_RX
	fi
	if [ $BOARD_TYPE -eq 1 ] ; then
		# E3 board test
		MASTER_CH=0
		MASTER_TX=$PREFNAME$MASTER_CH$SUFFNAME_TX
		MASTER_RX=$PREFNAME$MASTER_CH$SUFFNAME_RX
		#MASTERRW="rw"
		unset SLAVERW
	fi

	echo "> Transfer : ${WORD_SIZE}[bits/word] ${LEN}[words] M:${MASTERRW}, S:${SLAVERW}"

	# request transfer
	if [ $TRANSMODE -eq 1 ] ; then
		./test_msiof_transfer -s -n ${SLAVE_CH} -rw ${SLAVERW} -b ${WORD_SIZE} -w ${LEN}  -f ${SPEED} -dt 1 &
	fi
	sleep 1

	./test_msiof_transfer -m -n ${MASTER_CH} -rw ${MASTERRW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}
#sync
	# wait transfer end
	wait
	# compare data

	if [ $TRANSMODE -eq 0 -a ${TESTMODE} -eq 3 ] ; then
		if ! cmp ${MASTER_TX} ${MASTER_RX}
		then
			echo "***** Failed to Transfer (Master tx != Master rx)"
			return 1
		fi
	fi

	if [ $TRANSMODE -eq 1 -a ${TESTMODE} -eq 3 ] ; then
		if ! cmp ${SLAVE_RX} ${SLAVE_TX}
		then
			echo "***** Failed to Transfer (Slave rx != Slave tx)"
#			return 1
			return 0
		fi
	fi

	echo "> Transfer Succeeded"
	return 0
}

###############################################################################
#
# Main
#
###############################################################################

echo "***** MSIOF Loopback Test Start *****"

echo "----- Normal case -----"

if [ $# -eq 0 ] ; then
	echo "Transfer mode error"
	echo " cmd [time] [p/d] [board type]"
	echo "  [time]: 1800min"
	echo "  [p/d]: pio or dma"
	echo "  [board]: h3 or m3 or m3n or e3"
#	echo "  []: tx, rx, tx/rx"
	exit 0
fi

#arg1: Time
END_TIME=$1

#arg2: PIO or DMA
if [ $2 = "d" ] ; then
	ACCESS_MODE=0
elif [ $2 = "p" ] ; then
	ACCESS_MODE=1
else
	echo "DMA/PIO mode error"
	exit 0
fi

#arg3
#if [ $# -ge 3 ] ; then
#TRANSMODE=$3
#fi
TRANSMODE=1

#if [ $1 = "m" ] ; then
#	TRANSMODE=0
#elif [ $1 = "s" ] ; then
#	TRANSMODE=1
#else
#	echo "Transfer mode error"
#	exit 0
#fi
#
#if [ $2 -gt 3 ] ; then
#	echo "Transfer mode error"
#	exit 0
#elif [ $2 -lt 1 ] ; then
#	echo "Transfer mode error"
#	exit 0
#fi
#TESTMODE=$2


#arg3: board
if [ $# -eq 3 ] ; then
if [ $3 = "h3" ] ; then
	BOARD_TYPE=0
elif [ $3 = "m3" ] ; then
	BOARD_TYPE=0
elif [ $3 = "m3n" ] ; then
	BOARD_TYPE=0
elif [ $3 = "e3" ] ; then
	# master test send and receive
	BOARD_TYPE=1
	TRANSMODE=0
fi
fi


sync

echo "Transfer mode="$TESTMODE

k=0
while [ "$test_time" -le "$1" ]
do
	for (( i = 0; i < ${#WORD_SIZE[*]}; i++))
	do
		if [ $ACCESS_MODE -eq 0 ] ; then
			# word table select
			if [ ${i} -eq 0 ] ; then
			  LEN=("${WORDS_DMA1[@]}")
			elif [ ${i} -eq 1 ] ; then
			  LEN=("${WORDS_DMA2[@]}")
			elif [ ${i} -eq 2 ] ; then
			  LEN=("${WORDS_DMA3[@]}")
			fi
		else
			if [ ${i} -eq 0 ] ; then
			  LEN=("${WORDS_PIO1[@]}")
			elif [ ${i} -eq 1 ] ; then
			  LEN=("${WORDS_PIO2[@]}")
			elif [ ${i} -eq 2 ] ; then
			  LEN=("${WORDS_PIO3[@]}")
			fi
		fi
		WORDLOOP=${#LEN[*]}

		for (( j = 0; j < ${WORDLOOP}; j++))
		do
			sync
			transfer ${WORD_SIZE[$i]} ${LEN[$j]}

			ret=$?

			if [ ${ret} -eq 1 ]
			then
				echo "***** MSIOF Loopback Test Failed... *****"
				exit 1
			fi
		done
	done
	get_time=`date +%s`
	test_time=`expr "$get_time" - "$start_time"`
done

echo "***** MSIOF Loopback Test Passed. *****"

