#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################
TEST_TIME=0
END_TIME=10		# 10sec
TERGET=0		# h:H3, m:m3

###############################################################################
#
# Main
#
###############################################################################
if [ $# -eq 0 ] ; then
	exit 0
fi

if [ $1 = "h" ] ; then
        TERGET=0
elif [ $1 = "m" ] ; then
        TERGET=1
else
        echo "board type error"
        exit 1
fi


sync

echo "***** SMP Multi-Instance Test No.01 start  *****"
#echo

taskset -c 0 ./32_SMP_Multi-Instance_transfar.sh s &
sleep 1s

if [ $TERGET -eq 0 ]; then
	taskset -c 1 ./32_SMP_Multi-Instance_transfar.sh m &
	taskset -c 2 ./32_SMP_Multi-Instance_transfar.sh m &
	taskset -c 3 ./32_SMP_Multi-Instance_transfar.sh m
elif [ $TERGET -eq 1 ]; then
	taskset -c 1 ./32_SMP_Multi-Instance_transfar.sh m
fi

sleep 3s
echo "**** No.01 end ****"


