#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################

MSIOF_TP="test_msiof_transfer"
MASTER_TX="ch0_tx_data.dat"
MASTER_RX="ch0_rx_data.dat"
SLAVE_TX="ch1_tx_data.dat"
SLAVE_RX="ch1_rx_data.dat"

#TRANSFER_MODE=(1)
#WORD_SIZE=(8 16 32 8 16 32)
WORD_SIZE=(8 16 32)
WORDS_DMA1=(16 256 260 272 378 512)
WORDS_DMA2=(16 110 256 264 272 380 512)
WORDS_DMA3=(4 16 116 256 268 272 384 512)
# 8bit, 16bit, 32bit
WORDS_PIO1=(9 277 508)
WORDS_PIO2=(8 270 380)
WORDS_PIO3=(12 260 288)

ERR_WORD_SIZE=(7 9 15 17 31 33)

# test MSIOF channels
#  MSIOF0, MSIOF1, MSIOF2, MSIOF3 -> ch0-3
#   MSIOF1=spidev2.0, MSIOF3=spidev4.0
MASTER_CH=0
#MASTER_CH=2
SLAVE_CH=1
SLAVE_M_CH=0
SLAVE_S_CH=1

# 0:Master mode
# 1:Slave mode
TRANSMODE=0
# 1:Master Tx, Slave Rx
# 2:Master Rx, Slave Tx
# 3:Master TxRx, Slave TxRx
TESTMODE=3

MASTER_RW=("w" "r" "rw")
SLAVE_M_RW=("w" "w" "w")
SLAVE_RW=("w" "r" "rw")
MASTERRW="rw"
SLAVERW="rw"
SPEED=8000000
# Fixd data 0xAA = 170
# set to Decimal number
FIXDATA=170

###############################################################################
#
# Methods
#
###############################################################################

transfer()
{
WORDSIZE=$1
LEN=$2

	unset MASTERRW
	unset SLAVERW
	RWINDEX=`expr ${TESTMODE} - 1`

	if [ $TRANSMODE -eq 0 ] ; then
		# master mode
		MASTERRW=${MASTER_RW[$RWINDEX]}
	else
		# slave mode
		MASTER_CH=$SLAVE_M_CH
		SLAVE_CH=$SLAVE_S_CH
		MASTERRW=${SLAVE_M_RW[$RWINDEX]}
		SLAVERW=${SLAVE_RW[$RWINDEX]}
	fi

	echo "> Transfer : ${WORDSIZE}[bits/word] ${LEN}[words] M:${MASTERRW}, S:${SLAVERW}"

	# request transfer
	if [ $TRANSMODE -eq 1 ] ; then
		./test_msiof_transfer -s -n ${SLAVE_CH} -rw ${SLAVERW} -b ${WORDSIZE} -w ${LEN}  -f ${SPEED} -dt 1 &
	fi

	sleep 1

	./test_msiof_transfer -m -n ${MASTER_CH} -rw ${MASTERRW} -b ${WORDSIZE} -w ${LEN} -f ${SPEED}

	# wait transfer end
	wait

	# compare data
	if [ $TRANSMODE -eq 0 -a ${TESTMODE} -eq 3 ] ; then
		if ! cmp ${MASTER_TX} ${MASTER_RX}
		then
			echo "***** Failed to Transfer (Master tx != Master rx)"
			return 1
		fi
	fi

	if [ $TRANSMODE -eq 1 -a ${TESTMODE} -eq 3 ] ; then
		if ! cmp ${SLAVE_RX} ${SLAVE_TX}
		then
			echo "***** Failed to Transfer (Slave rx != Slave tx)"
#			return 1
			return 0
		fi
	fi

	echo "> Transfer Succeeded"
	return 0
}

###############################################################################
#
# Main
#
###############################################################################
echo "--------------- Normal case ---------------"

if [ $# -lt 2 ] ; then
	echo "Transfer mode error"
	echo " arg1 m: master mode, s: slave mode"
	echo " arg2 1: tx, 2: rx, 3: tx/rx"
	echo " arg3 p:pio"
	exit 0
fi

if [ $2 = "1" ] ; then
	echo "***** MSIOF only transmits Test: Start *****"
elif [ $2 = "2" ] ; then
	echo "***** MSIOF only receives Test: Start *****"
elif [ $2 = "3" ] ; then
	echo "***** MSIOF loopback Test: Start *****"
fi

# m:Master mode, s:Slave mode
if [ $1 = "m" ] ; then
	TRANSMODE=0
elif [ $1 = "s" ] ; then
	TRANSMODE=1
else
	echo "Transfer mode error"
	exit 0
fi

# test no. No.1-3
if [ $2 -gt 3 -o $2 -lt 1 ] ; then
	echo "Transfer mode error"
	exit 0
fi

#
TESTMODE=$2


# d: DMA mdoe, p: PIO mode
if [ $# -ge 3 ] ; then
	if [ $3 = "p" ] ; then
		ACCESS_MODE=1
	else
		ACCESS_MODE=0
	fi
else
	ACCESS_MODE=0
fi

sync

echo "Transfer mode="$TESTMODE

k=0
for (( i = 0; i < ${#WORD_SIZE[*]}; i++))
do
	# word table select
	if [ $ACCESS_MODE -eq 0 ] ; then
		# word table select
		if [ ${i} -eq 0 ] ; then
		  WORD_LEN=("${WORDS_DMA1[@]}")
		elif [ ${i} -eq 1 ] ; then
		  WORD_LEN=("${WORDS_DMA2[@]}")
		elif [ ${i} -eq 2 ] ; then
		  WORD_LEN=("${WORDS_DMA3[@]}")
		fi
	else
		if [ ${i} -eq 0 ] ; then
		  WORD_LEN=("${WORDS_PIO1[@]}")
		elif [ ${i} -eq 1 ] ; then
		  WORD_LEN=("${WORDS_PIO2[@]}")
		elif [ ${i} -eq 2 ] ; then
		  WORD_LEN=("${WORDS_PIO3[@]}")
		fi
	fi
	WORDLOOP=${#WORD_LEN[*]}

	for (( j = 0; j < ${WORDLOOP}; j++))
	do
		sync
		transfer ${WORD_SIZE[$i]} ${WORD_LEN[$j]}

		ret=$?

		if [ ${ret} -eq 1 ]
		then
			echo "***** MSIOF Test Failed... *****"
			exit 1
		fi
	done
done

if [ $2 = "1" ] ; then
	echo "***** MSIOF only transmits Test: Passed *****"
elif [ $2 = "2" ] ; then
	echo "***** MSIOF only receives Test: Passed *****"
else
	echo "***** MSIOF loopback Test: Passed *****"
fi