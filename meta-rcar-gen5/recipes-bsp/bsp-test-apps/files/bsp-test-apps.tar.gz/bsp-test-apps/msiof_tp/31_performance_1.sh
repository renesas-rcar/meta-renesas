#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################
TEST_TIME=0
END_TIME=50		# 30sec

###############################################################################
#
# Main
#
###############################################################################

if [ $# -lt 2 ] ; then
	echo "Error in argument.\n  p1:master ch, p2:transfer speed"
	exit 0
fi


MCH=$1
SPEED=$2

if [ $SPEED -eq 0 ] ; then
	echo "Parameter error. transfer speed is zero"
	exit 0
fi

echo "***** Performance No.1 start. *****"
sync

#i=0
START_TIME=`date +%s`
while [ ${TEST_TIME} -lt ${END_TIME} ]
do
	#transfer
	./test_msiof_transfer -m -n ${MCH} -rw rw -b 8 -w 16 -f ${SPEED}
	GET_TIME=`date +%s`
	TEST_TIME=`expr ${GET_TIME} - ${START_TIME}`
#	i=`expr $i + 1`
done

#echo "execute count = "$i
echo "***** Performance No.1 Passed. *****"


