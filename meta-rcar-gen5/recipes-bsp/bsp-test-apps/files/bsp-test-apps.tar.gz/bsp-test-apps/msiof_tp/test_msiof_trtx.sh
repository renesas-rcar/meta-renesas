#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################


#TRANSFER_MODE=(1)
WORD_SIZE=(8 16 32)
WORDS_DMA1=(16 256 260 272 378 512)
WORDS_DMA2=(16 110 256 264 272 380 512)
WORDS_DMA3=(4 16 116 256 268 272 384 512)
# 8bit, 16bit, 32bit
WORDS_PIO1=(9 277 508)
WORDS_PIO2=(8 270 380)
WORDS_PIO3=(12 260 288)

# test MSIOF channels
#  MSIOF0, MSIOF1, MSIOF2, MSIOF3 -> ch0-3
#   MSIOF1=spidev2.0, MSIOF3=spidev4.0
#MASTER_CH=3
#MASTER_CH=1
#SLAVE_CH=3
#SLAVE_M_CH=1
#SLAVE_S_CH=3

TARGET_CH=1

# 0:Master mode
# 1:Slave mode
TRANSMODE=0
# 1:Master Tx, Slave Rx
# 2:Master Rx, Slave Tx
# 3:Master TxRx, Slave TxRx
TESTMODE=3

RW_MODE=("w" "r" "rw")
#SLAVE_M_RW=("w" "w" "w")
#SLAVE_RW=("w" "r" "rw")
TEST_RW="rw"
#SLAVERW="rw"
SPEED=4000000
# Fixd data 0xAA = 170
# set to Decimal number
FIXDATA=170

###############################################################################
#
# Methods
#
###############################################################################

transfer()
{
WORDSIZE=$1
LEN=$2

	unset TEST_RW
	RWINDEX=`expr ${TESTMODE} - 1`

	TEST_RW=${RW_MODE[$RWINDEX]}

	echo "> Transfer : ${WORDSIZE}[bits/word] ${LEN}[words] RW=${TEST_RW}"

	# request transfer
	if [ $TRANSMODE -eq 1 ] ; then
		./test_msiof_transfer -s -n ${TARGET_CH} -rw ${TEST_RW} -b ${WORDSIZE} -w ${LEN} -f ${SPEED} -dt 1 &
	else
		./test_msiof_transfer -m -n ${TARGET_CH} -rw ${TEST_RW} -b ${WORDSIZE} -w ${LEN} -f ${SPEED}
	fi

	# wait transfer end
	wait

	# compare data
#	if [ $TRANSMODE -eq 0 -a ${TESTMODE} -eq 3 ] ; then
#		if ! cmp ${MASTER_TX} ${MASTER_RX}
#		then
#			echo "***** Failed to Transfer (Master tx != Master rx)"
#			return 1
#		fi
#	fi
#
#	if [ $TRANSMODE -eq 1 -a ${TESTMODE} -eq 3 ] ; then
#		if ! cmp ${SLAVE_RX} ${SLAVE_TX}
#		then
#			echo "***** Failed to Transfer (Slave rx != Slave tx)"
#			return 0
#		fi
#	fi
#
#	echo "> Transfer Succeeded"
	return 0
}

###############################################################################
#
# Main
#
###############################################################################

echo "***** MSIOF Loopback Test Start *****"

echo "----- Normal case -----"

PNUM=$#
P1=$1
P2=$2
if [ $# -gt 2 ] ; then
P3=$3
fi
if [ $# -gt 3 ] ; then
P4=$4
fi

if [ $PNUM -lt 2 ] ; then
	echo "This shell script only performs master or slave transfers."
	echo " arg1 [ch]: 0-3"
	echo " arg1 m: master mode, s: slave mode"
	echo " arg2 1: tx, 2: rx, 3: tx/rx"
	echo " arg3 p:pio"
	exit 0
fi

expr "$P1" + 1 >/dev/null 2>&1

if [ $? -lt 2 ] ; then
	if [ $P1 -ge "0" -a $P1 -le "3" ] ; then
		TARGET_CH=$P1
		PNUM=`expr $PNUM - 1`
		P1=$2
		if [ $PNUM -gt 1 ] ; then
			P2=$P3
		else
			echo "test mode error"
		fi
		if [ $PNUM -gt 2 ] ; then
			P3=$P4
		fi
	fi
fi
# m:Master mode, s:Slave mode
if [ $P1 = "m" ] ; then
	TRANSMODE=0
elif [ $P1 = "s" ] ; then
	TRANSMODE=1
else
	echo "Transfer mode error"
	exit 0
fi

# test no. No.1-3
if [ $P2 -gt 3 -o $P2 -lt 1 ] ; then
	echo "Transfer mode error"
	exit 0
fi

# 
TESTMODE=$P2

# d: DMA mdoe, p: PIO mode
if [ $PNUM -ge 3 ] ; then
	if [ $P3 = "p" ] ; then
		ACCESS_MODE=1
	else
		ACCESS_MODE=0
	fi
else
	ACCESS_MODE=0
fi


sync

echo "Transfer mode="$TESTMODE

k=0
for (( i = 0; i < ${#WORD_SIZE[*]}; i++))
do
	# word table select
	if [ $ACCESS_MODE -eq 0 ] ; then
		# word table select
		if [ ${i} -eq 0 ] ; then
		  WORD_LEN=("${WORDS_DMA1[@]}")
		elif [ ${i} -eq 1 ] ; then
		  WORD_LEN=("${WORDS_DMA2[@]}")
		elif [ ${i} -eq 2 ] ; then
		  WORD_LEN=("${WORDS_DMA3[@]}")
		fi
	else
		if [ ${i} -eq 0 ] ; then
		  WORD_LEN=("${WORDS_PIO1[@]}")
		elif [ ${i} -eq 1 ] ; then
		  WORD_LEN=("${WORDS_PIO2[@]}")
		elif [ ${i} -eq 2 ] ; then
		  WORD_LEN=("${WORDS_PIO3[@]}")
		fi
	fi
	WORDLOOP=${#WORD_LEN[*]}

	for (( j = 0; j < ${WORDLOOP}; j++))
	do
		sync
		transfer ${WORD_SIZE[$i]} ${WORD_LEN[$j]}

		ret=$?

		if [ ${ret} -eq 1 ]
		then
			echo "***** MSIOF Loopback Test Failed... *****"
			exit 1
		fi
	done
done

echo "***** MSIOF Loopback Test Passed. *****"

