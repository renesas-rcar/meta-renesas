./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 16666666 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 8000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 7000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 6000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 5000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 4000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 3000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 2500000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 2000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 1500000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 1000000 ; sync
./test_msiof_transfer -m -n 3 -rw w -b 8 -w 128 -f 500000 ; sync

