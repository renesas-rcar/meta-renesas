#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################
TEST_TIME=0
END_TIME=15		# 10sec
TRANS_MODE=0

###############################################################################
#
# Main
#
###############################################################################
if [ $# -lt 1 ] ; then
	echo "argument error"
	exit 0
fi

if [ $1 = "m" ] ; then
        TRANS_MODE=0
elif [ $1 = "s" ] ; then
        TRANS_MODE=1
else
        echo "Transfer mode error"
        exit 0
fi

sync

if [ $TRANS_MODE -eq 0 ] ; then
	echo "Master mdoe start"
else
	echo "Slave mdoe start"
fi

START_TIME=`date +%s`


while [ ${TEST_TIME} -lt ${END_TIME} ]
do
	#transfer
	if [ $TRANS_MODE -eq 0 ] ; then
		sleep 1s
		./test_msiof_transfer -m -n 1 -rw rw -b 32 -w 512
	else
		./test_msiof_transfer -s -n 3 -rw rw -b 32 -w 512
		sleep 1
	fi
	GET_TIME=`date +%s`
	TEST_TIME=`expr ${GET_TIME} - ${START_TIME}`
done

if [ $TRANS_MODE -eq 0 ] ; then
	echo "***** Master mode Passed. *****"
else
	echo "***** Slave mode Passed. *****"
fi


