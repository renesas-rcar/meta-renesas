
################################################################################
#workspace=~/
#script=${workspace}msiof_tp
# ./msiof_execute.sh $1 $2 $3
# $1 m/s
# $2 1/2/3
# $3 1/2/3
################################################################################

MSIOF_TP="test_msiof_transfer"
MASTER_TX="ch0_tx_data.dat"
MASTER_RX="ch0_rx_data.dat"
SLAVE_TX="ch0_tx_data.dat"
SLAVE_RX="ch0_rx_data.dat"

#TRANSFER_MODE=(1)
#WORD_SIZE=(8 16 32 8 16 32)
WORD_SIZE=(8 16 32)
WORDS1=(16 256 260 272 378 512)
WORDS2=(16 110 256 264 272 380 512)
WORDS3=(4 16 116 256 268 272 384 512)
WORDS4=(9 277 508)
WORDS5=(8 270 380)
WORDS6=(12 260 288)

ERR_WORD_SIZE=(7 9 15 17 31 33)

# test MSIOF channels
#  MSIOF0, MSIOF1, MSIOF2, MSIOF3 -> ch0-3
#   MSIOF1=spidev2.0, MSIOF3=spidev4.0
MASTER_CH=0
SLAVE_CH=0

# 0:Master mode
# 1:Slave mode
TRANSMODE=0
# 1:Master Tx, Slave Rx
# 2:Master Rx, Slave Tx
# 3:Master TxRx, Slave TxRx
TESTMODE=3
MASTERRW="rw"
SLAVERW="rw"
SPEED=4000000
# Fixd data 0xAA = 170
# set to Decimal number
FIXDATA=170
master_ip="192.168.10.33"
###############################################################################
#
# Methods
#
###############################################################################

transfer()
{
	# data select
        if [ $1 -eq 0 ] ; then
          LEN=${WORDS1[$2]}
        elif [ $1 -eq 1 ] ; then
          LEN=${WORDS2[$2]}
        elif [ $1 -eq 2 ] ; then
          LEN=${WORDS3[$2]}
        fi
#        TESTMODE=${TRANSFER_MODE[$3]}

	unset MASTERRW
	unset SLAVERW
	if [ $TRANSMODE -eq 0 ] ; then
		# master mode
		if [ $TESTMODE -eq 1 ] ; then
			MASTERRW=w
		elif [ $TESTMODE -eq 2 ] ; then
			MASTERRW=r
		elif [ $TESTMODE -eq 3 ] ; then
			MASTERRW=rw
		fi
	else
		unset MASTER_CH
		unset SLAVE_CH
		MASTER_CH=0
		SLAVE_CH=0
		# slave mode
		if [ $TESTMODE -eq 1 ] ; then
			MASTERRW=w
			SLAVERW=w
		elif [ $TESTMODE -eq 2 ] ; then
			MASTERRW=w
			SLAVERW=r
		elif [ $TESTMODE -eq 3 ] ; then
			MASTERRW=w
			SLAVERW=rw
		fi
	fi

	echo "> Transfer : ${WORD_SIZE[$1]}[bits/word] ${LEN}[words] M:${MASTERRW}, S:${SLAVERW}"
	#cd /home/root/msiof_tp/
	# request transfer
	if [ $TRANSMODE -eq 1 ] ; then
		./test_msiof_transfer -s -n ${SLAVE_CH} -rw ${SLAVERW} -b ${WORD_SIZE[$1]} -w ${LEN}  -f ${SPEED} -dt 1 &
		sleep 1
		ssh root@$master_ip /home/root/msiof_tp/test_msiof_transfer -m -n ${MASTER_CH} -rw ${MASTERRW} -b ${WORD_SIZE[$1]} -w ${LEN} -f ${SPEED}

	else
		./test_msiof_transfer -m -n ${MASTER_CH} -rw ${MASTERRW} -b ${WORD_SIZE[$1]} -w ${LEN} -f ${SPEED}	
	
	fi

	# wait transfer end
	wait

	# compare data
	if [ $TRANSMODE -eq 0 -a ${TESTMODE} -eq 3 ] ; then
		if ! cmp ${MASTER_TX} ${MASTER_RX}
		then
			echo "***** Failed to Transfer (Master tx != Master rx)"
			return 1
		fi
	fi

	if [ $TRANSMODE -eq 1 -a ${TESTMODE} -eq 3 ] ; then
		if ! cmp ${SLAVE_RX} ${SLAVE_TX}
		then
			echo "***** Failed to Transfer (Slave rx != Slave tx)"
			return 1
		fi
	fi

	echo "> Transfer Succeeded"
	return 0
}

###############################################################################
#
# Main
#
###############################################################################

	if [ $1 = "m" ] ; then
		_mode="master"
	elif [ $1 = "s" ] ; then
		_mode="slave"
	else
		echo "Please type "m/s""
		exit 1
	fi
	
	if [ $2 -eq 1 ] ; then
		_test="w"
	elif [ $2 -eq 2 ] ; then
		_test="r"
	elif [ $2 -eq 3 ] ; then
		_test="rw"
	else
		echo "Please type "1/2/3""
		exit 1
	fi
	
	if [ $3 -eq 1 ] ; then
		_words=8
	elif [ $3 -eq 2 ] ; then
		_words=16
	elif [ $3 -eq 3 ] ; then
		_words=32
	else
		echo "Please type "1/2/3""
		exit 1
	fi
	
	echo "____START_MSIOF_Loopback_test____"
	dmesg | grep iommu
	echo ""
	#cd ${script}/msiof/
	#cd /home/root/msiof_tp/
	
	find . *data.dat
	if [ $? -eq 0 ]; then
		echo "Cleaning old test sample file"
		rm *data.dat
		echo "Cleaned"
	fi
	
	if [ $# -ne 3 ] ; then
		echo "Useage ./msiof_execute.sh [TRANSMODE] [TESTMODE] [WORDS]"
		echo " TRANSMODE: m (master), s (slave)"
		echo " TESTMODE: 1 (w), 2 (r), 3 (rw)"
		echo " WORDS: 1 (IOMMU 8bit transfer), 2 (IOMMU 16bit transfer), 3 (IOMMU 32bit transfer)"
		exit 0
	fi
	
	if [ $1 = "m" ] ; then
		TRANSMODE=0
	elif [ $1 = "s" ] ; then
		TRANSMODE=1
	else
		echo "Transfer mode error"
		exit 0
	fi
	
	if [ $2 -gt 3 ] ; then
		echo "Transfer mode error"
		exit 0
	elif [ $2 -lt 1 ] ; then
		echo "Transfer mode error"
		exit 0
	fi
	
	TESTMODE=$2
	
	echo "Transfer mode="$TESTMODE
	
	k=0
	#for (( i = 0; i < ${#WORD_SIZE[*]}; i++))
	#do
		# word table select
	#	if [ ${i} -eq 0 ] ; then
	#	  WORDLOOP=${#WORDS1[*]}
	#	elif [ ${i} -eq 1 ] ; then
	#	  WORDLOOP=${#WORDS2[*]}
	#	elif [ ${i} -eq 2 ] ; then
	#	  WORDLOOP=${#WORDS3[*]}
	#	elif [ ${i} -eq 3 ] ; then
	#	  WORDLOOP=${#WORDS4[*]}
	#	elif [ ${i} -eq 4 ] ; then
	#	  WORDLOOP=${#WORDS5[*]}
	#	elif [ ${i} -eq 5 ] ; then
	#	  WORDLOOP=${#WORDS6[*]}
	#	fi
	
	case $3 in
	1)
		WORDLOOP=${#WORDS1[*]}
		i=0
		;;
	2)
		WORDLOOP=${#WORDS2[*]}
		i=1
		;;
	3)
		WORDLOOP=${#WORDS3[*]}
		i=2
		;;
	esac
	
		for (( j = 0; j < ${WORDLOOP}; j++))
		do
			transfer ${i} ${j}
	
			ret=$?
	
			if [ ${ret} -eq 1 ]
			then
				echo "____FINISH"
				sleep 0.1
				echo "____FINISH_MSIOF_Loopback_test_mode_${_mode}_${_test}_${_words}_NG____"
				exit 1
			fi
		done
	#done
	
	#echo "----- Error case -----"
	#
	#for (( e = 0; e < ${#ERR_WORD_SIZE[*]}; e++))
	#do
	#	check_word_size ${e}
	#done
	
	echo "____FINISH"
	sleep 0.1
	echo "____FINISH_MSIOF_Loopback_test_mode_${_mode}_${_test}_${_words}_OK____"
	exit 0
