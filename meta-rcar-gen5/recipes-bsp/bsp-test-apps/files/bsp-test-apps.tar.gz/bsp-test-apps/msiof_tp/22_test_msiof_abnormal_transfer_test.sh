#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################

#TERGET_CH=3
#OTHER_CH=1
M_CH=0
S_CH=1
SPEED=4000000

#TRANSFER_MODE=(1 2 3)
TRANSFER_MODE=(1)
WORD_SIZE=8

# 0:Master mode
# 1:Slave mode
TRANSMODE=0

# 0:DMA mode
# 1:PIO mode
DMAMODE=0

# 1:Master Tx, Slave Rx
# 2:Master Rx, Slave Tx
# 3:Master TxRx, Slave TxRx
TESTMODE=3

# 0: single test
# 1: All test
TEST_MODE=0
TERGET_RW="rw"
TEST_NO=0
TITLE_TEST_MODE=("transmission"  "Received" "transmission/Received")
TITLE_MST_SLV=("Master"  "Slave")
TITLE_MASTER_DMA=(1 3 5)
TITLE_MASTER_PIO=(2 4 6)
TITLE_SLAVE_DMA=(7 9 11)
TITLE_SLAVE_PIO=(8 10 12)


Transfer_Master()
{
#$1 : bit  8, 16, 32
#$2 : ren  
WORD_SIZE=$1
LEN=$2

	if [ $TESTMODE -eq 0 ] ; then
		TERGET_RW=w
	elif [ $TESTMODE -eq 1 ] ; then
		TERGET_RW=r
	elif [ $TESTMODE -eq 2 ] ; then
		TERGET_RW=rw
	fi

	# Transmission/Received
	./test_msiof_transfer -m -n ${M_CH} -rw ${TERGET_RW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}
}


Transfer_Slave()
{
#$1 : bit  8, 16, 32
#$2 : ren  
WORD_SIZE=$1
LEN=$2

	if [ $TESTMODE -eq 0 ] ; then
		TERGET_RW=w
	elif [ $TESTMODE -eq 1 ] ; then
		TERGET_RW=r
	elif [ $TESTMODE -eq 2 ] ; then
		TERGET_RW=rw
	fi

	# Transmission data/Received data
	./test_msiof_transfer -s -n ${S_CH} -rw ${TERGET_RW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED} &

	sleep 1
	# dummy send(sync, clk)
	./test_msiof_transfer -m -n ${M_CH}  -rw w            -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}
}


transfer_dma()
{
	if [ $TRANSMODE -eq 0 ] ; then
		TEST_NO=${TITLE_MASTER_DMA[$TESTMODE]}
	else
		TEST_NO=${TITLE_SLAVE_DMA[$TESTMODE]}
	fi

	echo "No.$TEST_NO(${TITLE_MST_SLV[$TRANSMODE]} ${TITLE_TEST_MODE[$TESTMODE]}): 16bit  5, 89, 267, 385byte"
	for VAL_LEN in 5 89 267 385
	do
		echo "  > 16bit ${VAL_LEN}byte"
		if [ $TRANSMODE -eq 0 ] ; then
			# Master mode
			Transfer_Master 16 $VAL_LEN
		else
			# Slave mode
			Transfer_Slave 16 $VAL_LEN
		fi
		sleep 1
		sync
	done

	echo "No.$TEST_NO(${TITLE_MST_SLV[$TRANSMODE]} ${TITLE_TEST_MODE[$TESTMODE]}): 32bit 10, 98, 262, 506byte"
	for VAL_LEN in 10 98 262 506
	do
		echo "  > 32bit ${VAL_LEN}byte"
		if [ $TRANSMODE -eq 0 ] ; then
			# Master mode
			Transfer_Master 32 $VAL_LEN
		else
			# Slave mode
			Transfer_Slave 32 $VAL_LEN
		fi
		sleep 1
		sync
	done
}


transfer_pio()
{
	if [ $TRANSMODE -eq 0 ] ; then
		TEST_NO=${TITLE_MASTER_PIO[$TESTMODE]}
	else
		TEST_NO=${TITLE_SLAVE_PIO[$TESTMODE]}
	fi

	echo "No.$TEST_NO(${TITLE_MST_SLV[$TRANSMODE]} ${TITLE_TEST_MODE[$TESTMODE]}): 16bit  11, 281byte"
	for VAL_LEN in 11 281
	do
		echo "  > 16bit ${VAL_LEN}byte"
		if [ $TRANSMODE -eq 0 ] ; then
			# Master mode
			Transfer_Master 16 $VAL_LEN
		else
			# Slave mode
			Transfer_Slave 16 $VAL_LEN
		fi
		sleep 1
		sync
	done

	echo "No.$TEST_NO(${TITLE_MST_SLV[$TRANSMODE]} ${TITLE_TEST_MODE[$TESTMODE]}): 32bit 6, 274byte"
	for VAL_LEN in 6 274
	do
		echo "  > 32bit ${VAL_LEN}byte"
		if [ $TRANSMODE -eq 0 ] ; then
			# Master mode
			Transfer_Master 32 $VAL_LEN
		else
			# Slave mode
			Transfer_Slave 32 $VAL_LEN
		fi
		sleep 1
		sync
	done
}



###############################################################################
#
# Main
#
###############################################################################

echo "***** MSIOF Loopback Test Start *****"
# 2.2. Abnormal System Test

PNUM=$#
P1=$1
P2=$2
if [ $# -gt 2 ] ; then
P3=$3
fi
if [ $# -gt 3 ] ; then
P4=$4
fi

if [ $# -lt 2 ] ; then
	echo "<arg1> <arg2> <arg3>"
	echo "<arg1> Master/Slave mode error"
	echo "  m : mster mode"
	echo "  s : slave mode"
	echo "<arg2> DMA/PIO mode"
	echo "  d : DMA test"
	echo "  p : PIO test"
	echo "<arg3> Test mode"
	echo "  1 : Send test"
	echo "  2 : Recive test"
	echo "  3 : Send/Recive test"
	echo "  other : 1-3 test"
	exit 0
fi


expr "$P1" + 1 >/dev/null 2>&1

if [ $? -lt 2 ] ; then
	if [ $P1 -ge "0" -a $P1 -le "3" ] ; then
		M_CH=$P1
		PNUM=`expr $PNUM - 1`
		P1=$P2
		if [ $PNUM -gt 1 ] ; then
			P2=$P3
		else
			echo "test mode error"
		fi
		if [ $PNUM -gt 2 ] ; then
			P3=$P4
		fi

		#slave ch
		expr "$P1" + 1 >/dev/null 2>&1
		if [ $? -lt 2 ] ; then
			if [ $P1 -ge "0" -a $P1 -le "3" ] ; then

				S_CH=$P1
				PNUM=`expr $PNUM - 1`
				P1=$P2
				if [ $PNUM -gt 1 ] ; then
					P2=$P3
				else
					echo "test mode error"
				fi
				if [ $PNUM -gt 2 ] ; then
					P3=$P4
				fi
			fi
		fi
	fi
fi


# Master/Slave mode
if [ $P1 = "m" ] ; then
	TRANSMODE=0
elif [ $P1 = "s" ] ; then
	TRANSMODE=1
else
	echo "Transfer mode error"
	exit 0
fi

# DMA/PIO mode
if [ $P2 = "d" ] ; then
	DMAMODE=0
elif [ $P2 = "p" ] ; then
	DMAMODE=1
else
	echo "Transfer mode error"
	exit 0
fi


TESTMODE=0
if [ $PNUM -gt 2 ] ; then
	# arg3 Range check
	if [ $P3 -gt 3 ] ; then
		TEST_MODE=1
	elif [ $P3 -lt 1 ] ; then
		TEST_MODE=1
	else
#		TESTMODE=$3
		TESTMODE=`expr $3 - 1`
	fi
else
	# Run all tests
	TEST_MODE=1
fi

echo "PNUM="$PNUM


#echo "> TRANSMODE(m s) : ${TRANSMODE},  TEST_MODE= ${TEST_MODE}  TESTMODE=${TESTMODE}, bit: ${WORD_SIZE}, LEN: ${LEN} words"


if [ $DMAMODE -eq 1 ] ; then
	echo "----- Abnormal case PIO -----"
else
	echo "----- Abnormal case DMA -----"
fi

if [ $TEST_MODE -eq 1 ] ; then
	TESTMODE=0
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
	TESTMODE=1
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
	TESTMODE=2
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
else
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
fi

echo

echo "***** MSIOF Loopback Test Passed. *****"


