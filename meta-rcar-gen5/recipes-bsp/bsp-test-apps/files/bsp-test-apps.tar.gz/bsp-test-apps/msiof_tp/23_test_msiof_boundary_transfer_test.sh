#!/bin/bash

###############################################################################
#
# Defines
#
###############################################################################

MSIOF_TP="test_msiof_transfer"
CH1_TX_DATA="ch1_tx_data.dat"
CH1_RX_DATA="ch1_rx_data.dat"
TERGET_CH=0
OTHER_CH=1
SPEED=4000000

#TRANSFER_MODE=(1 2 3)
TRANSFER_MODE=(1)
WORD_SIZE=8

# 0:Master mode
# 1:Slave mode
TRANSMODE=0

# 0:DMA mode
# 1:PIO mode
DMAMODE=0

# 1:Master Tx, Slave Rx
# 2:Master Rx, Slave Tx
# 3:Master TxRx, Slave TxRx
TESTMODE=3

# 0: single test
# 1: All test
TEST_MODE=0
TERGET_RW="rw"
TEST_NO=0
TITLE_TEST_MODE=("transmission"  "Received" "transmission/Received")
TITLE_MST_SLV=("Master"  "Slave")
TITLE_MASTER_DMA=(1 3 5)
TITLE_MASTER_PIO=(2 4 6)
TITLE_SLAVE_DMA=(7 9 11)
TITLE_SLAVE_PIO=(8 10 12)

Transfer_Data()
{
#$1 : bit  8, 16, 32
#$2 : ren  
WORD_SIZE=${1}
LEN=${2}

	if [ $TESTMODE -eq 0 ] ; then
		TERGET_RW=w
	elif [ $TESTMODE -eq 1 ] ; then
		TERGET_RW=r
	elif [ $TESTMODE -eq 2 ] ; then
		TERGET_RW=rw
	fi

	if [ $TRANSMODE -eq 0 ] ; then
	# Master mode
		# Transmission/Received
		./test_msiof_transfer -m -n ${TERGET_CH} -rw ${TERGET_RW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}
	else
		# Transmission data/Received data
		./test_msiof_transfer -s -n ${TERGET_CH} -rw ${TERGET_RW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED} &

		sleep 1
		# dummy send(sync, clk)
		./test_msiof_transfer -m -n ${OTHER_CH}  -rw w            -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}
		sync
	fi

	if [ $TESTMODE -eq 2 ] ; then
		sleep 1
		sync
		echo "transfer data check!"
		sync
		cmp $CH1_TX_DATA $CH1_RX_DATA
		sleep 1
		sync
	fi
}


Transfer_Master()
{
#$1 : bit  8, 16, 32
#$2 : ren  
WORD_SIZE=${1}
LEN=${2}

	if [ $TESTMODE -eq 0 ] ; then
		TERGET_RW=w
	elif [ $TESTMODE -eq 1 ] ; then
		TERGET_RW=r
	elif [ $TESTMODE -eq 2 ] ; then
		TERGET_RW=rw
	fi

	# Transmission/Received
	./test_msiof_transfer -m -n ${TERGET_CH} -rw ${TERGET_RW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}
	if [ $TESTMODE -eq 2 ] ; then
		sleep 1
		sync
		echo "transfer data check!"
		sync
		cmp $CH1_TX_DATA $CH1_RX_DATA
		sleep 1
		sync
	fi
}


Transfer_Slave()
{
#$1 : bit  8, 16, 32
#$2 : ren  
WORD_SIZE=${1}
LEN=${2}

	if [ $TESTMODE -eq 0 ] ; then
		TERGET_RW=w
	elif [ $TESTMODE -eq 1 ] ; then
		TERGET_RW=r
	elif [ $TESTMODE -eq 2 ] ; then
		TERGET_RW=rw
	fi

	# Transmission data/Received data
	./test_msiof_transfer -s -n ${TERGET_CH} -rw ${TERGET_RW} -b ${WORD_SIZE} -w ${LEN} -f ${SPEED} &

	sleep 1
	# dummy send(sync, clk)
	./test_msiof_transfer -m -n ${OTHER_CH}  -rw w            -b ${WORD_SIZE} -w ${LEN} -f ${SPEED}

	if [ $TESTMODE -eq 2 ] ; then
		sync
		echo "transfer data check!"
		sync
		cmp $CH1_TX_DATA $CH1_RX_DATA
		sleep 1
		sync
	fi
}

BIT_MODE_DMA=(8 16 8 16 32)
WORD_LEN1_DMA=(1 15 17 63 64 65 255 257 271 273 511 513)
WORD_LEN2_DMA=(128)
WORD_LEN3_DMA=(0)
WORD_LEN4_DMA=(0 1 3 15 17 127 129 255 257 271 273 511 513)
WORD_LEN5_DMA=(0 1 3 15 17 255 257 271 273 511 513)

BIT_MODE_PIO=(8 16 32 8 16 32)
WORD_LEN1_PIO=(1 15 16 17 63 64 65)
WORD_LEN2_PIO=(16 64)
WORD_LEN3_PIO=(16 256)
WORD_LEN4_PIO=(0)
WORD_LEN5_PIO=(0 1 15 17 63 65)
WORD_LEN6_PIO=(0 1 15 17 257)


transfer_dma()
{
	if [ $TRANSMODE -eq 0 ] ; then
		TEST_NO=${TITLE_MASTER_DMA[$TESTMODE]}
	else
		TEST_NO=${TITLE_SLAVE_DMA[$TESTMODE]}
	fi

	BIT_MAX=`expr "${#BIT_MODE_DMA[*]}" - 1`
	for i in `seq 0 ${BIT_MAX}`
	do
		if [ $i -eq 0 ] ; then
			NEW_WORD_LEN=("${WORD_LEN1_DMA[@]}")
		elif [ $i -eq 1 ] ; then
			NEW_WORD_LEN=("${WORD_LEN2_DMA[@]}")
		elif [ $i -eq 2 ] ; then
			NEW_WORD_LEN=("${WORD_LEN3_DMA[@]}")
		elif [ $i -eq 3 ] ; then
			NEW_WORD_LEN=("${WORD_LEN4_DMA[@]}")
		elif [ $i -eq 4 ] ; then
			NEW_WORD_LEN=("${WORD_LEN5_DMA[@]}")
		fi

		echo "No.${TEST_NO}(${TITLE_MST_SLV[$TRANSMODE]} ${TITLE_TEST_MODE[$TESTMODE]}): ${BIT_MODE_DMA[$i]}bit  ${NEW_WORD_LEN[@]}byte"
		WORD_LEN_MAX=`expr "${#NEW_WORD_LEN[*]}" - 1`
		for j in `seq 0 ${WORD_LEN_MAX}`
		do
			echo "  > ${BIT_MODE_DMA[$i]}bit ${NEW_WORD_LEN[$j]}byte"
			sync
			Transfer_Data ${BIT_MODE_DMA[$i]} ${NEW_WORD_LEN[$j]}
			sync
			sleep 1
		done
	done
}


transfer_pio()
{
	if [ $TRANSMODE -eq 0 ] ; then
		TEST_NO=${TITLE_MASTER_PIO[$TESTMODE]}
	else
		TEST_NO=${TITLE_SLAVE_PIO[$TESTMODE]}
	fi


	BIT_MAX=`expr "${#BIT_MODE_PIO[*]}" - 1`
	for i in `seq 0 ${BIT_MAX}`
	do
		if [ $i -eq 0 ] ; then
			NEW_WORD_LEN=("${WORD_LEN1_PIO[@]}")
		elif [ $i -eq 1 ] ; then
			NEW_WORD_LEN=("${WORD_LEN2_PIO[@]}")
		elif [ $i -eq 2 ] ; then
			NEW_WORD_LEN=("${WORD_LEN3_PIO[@]}")
		elif [ $i -eq 3 ] ; then
			NEW_WORD_LEN=("${WORD_LEN4_PIO[@]}")
		elif [ $i -eq 4 ] ; then
			NEW_WORD_LEN=("${WORD_LEN5_PIO[@]}")
		elif [ $i -eq 5 ] ; then
			NEW_WORD_LEN=("${WORD_LEN6_PIO[@]}")
		fi

		echo "No.${TEST_NO}(${TITLE_MST_SLV[$TRANSMODE]} ${TITLE_TEST_MODE[$TESTMODE]}): ${BIT_MODE_PIO[$i]}bit  ${NEW_WORD_LEN[@]}byte"
		WORD_LEN_MAX=`expr "${#NEW_WORD_LEN[*]}" - 1`
		for j in `seq 0 ${WORD_LEN_MAX}`
		do
			echo "  > ${BIT_MODE_PIO[$i]}bit ${NEW_WORD_LEN[$j]}byte"
			sync
			if [ $TRANSMODE -eq 0 ] ; then
				# Master mode
				Transfer_Master ${BIT_MODE_DMA[$i]} ${NEW_WORD_LEN[$j]}
			else
				# Slave mode
				Transfer_Slave ${BIT_MODE_DMA[$i]} ${NEW_WORD_LEN[$j]}
			fi
			sleep 1
			sync
		done
	done

}



###############################################################################
#
# Main
#
###############################################################################

echo "***** MSIOF Loopback Test Start *****"
# 2.2. Boundary System Test

if [ $# -lt 2 ] ; then
	echo "<arg1> <arg2> <arg3>"
	echo "<arg1> Master/Slave mode error"
	echo "  m : mster mode"
	echo "  s : slave mode"
	echo "<arg2> DMA/PIO mode"
	echo "  d : DMA test"
	echo "  p : PIO test"
	echo "<arg3> Test mode"
	echo "  1 : Send test"
	echo "  2 : Recive test"
	echo "  3 : Send/Recive test"
	echo "  other : 1-3 test"
	exit 0
fi

# Master/Slave mode
if [ $1 = "m" ] ; then
	TRANSMODE=0
elif [ $1 = "s" ] ; then
	TRANSMODE=1
else
	echo "Transfer mode error"
	exit 0
fi

# DMA/PIO mode
if [ $2 = "d" ] ; then
	DMAMODE=0
elif [ $2 = "p" ] ; then
	DMAMODE=1
else
	echo "Transfer mode error"
	exit 0
fi


TESTMODE=0
if [ $# -gt 2 ] ; then
	# arg3 Range check
	if [ $3 -gt 3 ] ; then
		TEST_MODE=1
	elif [ $3 -lt 1 ] ; then
		TEST_MODE=1
	else
#		TESTMODE=$3
		TESTMODE=`expr $3 - 1`
	fi
else
	# Run all tests
	TEST_MODE=1
fi

#echo "> TRANSMODE(m s) : ${TRANSMODE},  TEST_MODE= ${TEST_MODE}  TESTMODE=${TESTMODE}, bit: ${WORD_SIZE}, LEN: ${LEN} words"


if [ $DMAMODE -eq 1 ] ; then
	echo "----- Boundary case PIO -----"
else
	echo "----- Boundary case DMA -----"
fi

if [ $TEST_MODE -eq 1 ] ; then
	TESTMODE=0
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
	TESTMODE=1
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
	TESTMODE=2
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
else
	if [ $DMAMODE -eq 1 ] ; then
		transfer_pio
	else
		transfer_dma
	fi
fi

echo
#sync
#transfer_dma_2
#echo
#sync
#transfer_dma_3

echo "***** MSIOF Loopback Test Passed. *****"


