OP-TEE Dispatcher
=================

[OP-TEE OS] is a Trusted OS running as Secure EL1.

To build and execute [OP-TEE OS] follow the instructions at
[ARM Trusted Firmware with OP-TEE] [OP-TEE OS]

- - - - - - - - - - - - - - - - - - - - - - - - - -

_Copyright (c) 2014, ARM Limited and Contributors. All rights reserved._

[OP-TEE OS]:  http://github.com/OP-TEE/optee_os/tree/master/documentation/arm_trusted_firmware.md
