#!/bin/sh

echo "Update firmware for ov10640/ov490 cameras {4-7} to 1280x800@30,UYVY,8bit,BT601,pclk=96MHz"

v4l2-fw -d /dev/video4 -w /usr/share/factory/OV10640_OV490_combine_general_v491_20160105_common_withSPIHeader_1280x800@30_96Mhz.bin
v4l2-fw -d /dev/video5 -w /usr/share/factory/OV10640_OV490_combine_general_v491_20160105_common_withSPIHeader_1280x800@30_96Mhz.bin
v4l2-fw -d /dev/video6 -w /usr/share/factory/OV10640_OV490_combine_general_v491_20160105_common_withSPIHeader_1280x800@30_96Mhz.bin
v4l2-fw -d /dev/video7 -w /usr/share/factory/OV10640_OV490_combine_general_v491_20160105_common_withSPIHeader_1280x800@30_96Mhz.bin

echo "Power off system to take effect for firmware update"
